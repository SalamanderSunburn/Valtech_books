var myApp=angular.module('myApp');
myApp.controller('phoneController', function($scope) {

  $scope.data = {visible:true};
  /*$scope.phones = [{
        name: 'Nokia',
        models:[{
			name: "Nokia Lumia 530",
			price: 150
		},{
			name: "Nokia X2",
			price: 200
		}]
    },{
        name: 'Samsung',
        models:[{
			name: "Samsung Galaxy S5",
			price: 500
		},{
			name: "Samsung Galaxy Alpha",
			price: 400
		}]
    }]*/
});